package com.example.PlayandFit_Box_cricket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayandFitBoxCricketApplicationTests {

	@Test
	void contextLoads() {
	}

}
