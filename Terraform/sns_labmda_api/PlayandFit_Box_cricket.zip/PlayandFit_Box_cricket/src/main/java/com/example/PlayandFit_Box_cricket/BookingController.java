package com.example.PlayandFit_Box_cricket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import software.amazon.awssdk.services.sns.SnsClient;
import software.amazon.awssdk.services.sns.model.PublishRequest;
import software.amazon.awssdk.services.sns.model.PublishResponse;
import org.springframework.stereotype.Component;
import java.util.function.Function;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingRepository bookingRepository;

    private final SnsClient snsClient;
    private final String topicArn = System.getenv("AWS_SNS_TOPIC_ARN");

    public BookingController() {
        this.snsClient = SnsClient.builder().build();
    }

    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @PostMapping
    public Booking addBooking(@RequestBody Booking booking) {
        Booking savedBooking = bookingRepository.save(booking);

        try {
            String message = String.format("Booking Confirmed!\nName: %s\nPhone: %s\nDate: %s\nTime: %s",
                    booking.getName(), booking.getPhoneNumber(), booking.getDate(), booking.getTime());

            PublishRequest request = PublishRequest.builder()
                    .message(message)
                    .topicArn(topicArn)
                    .build();

            PublishResponse response = snsClient.publish(request);
            System.out.println("SNS Message ID: " + response.messageId());
        } catch (Exception e) {
            System.err.println("Error sending SNS notification: " + e.getMessage());
        }

        return savedBooking;
    }
}
