package com.example.PlayandFit_Box_cricket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PlayandFitBoxCricketApplication {
    public static void main(String[] args) {
        SpringApplication.run(PlayandFitBoxCricketApplication.class, args);
    }
}
