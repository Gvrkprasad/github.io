import boto3

def lambda_handler(event, context):
    sns = boto3.client('sns')
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:123456789012:MyTopic',
        Message=f"Notification: {event['message']}",
        Subject="Lambda Notification",
    )
    return {
        'statusCode': 200,
        'body': f"Message sent: {response['MessageId']}"
    }
